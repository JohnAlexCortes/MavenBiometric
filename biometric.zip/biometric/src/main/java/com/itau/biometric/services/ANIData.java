
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ANIData complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ANIData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AnioResolucion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CodigoErrorDatosCedula" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DepartamentoExpedicion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EstadoCedula" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FechaExpedicion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MunicipioExpedicion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NUIP" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NumeroResolucion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Particula" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PrimerApellido" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PrimerNombre" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SegundoApellido" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SegundoNombre" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ANIData", propOrder = {
    "anioResolucion",
    "codigoErrorDatosCedula",
    "departamentoExpedicion",
    "estadoCedula",
    "fechaExpedicion",
    "municipioExpedicion",
    "nuip",
    "numeroResolucion",
    "particula",
    "primerApellido",
    "primerNombre",
    "segundoApellido",
    "segundoNombre"
})
public class ANIData {

    @XmlElement(name = "AnioResolucion")
    protected String anioResolucion;
    @XmlElement(name = "CodigoErrorDatosCedula")
    protected String codigoErrorDatosCedula;
    @XmlElement(name = "DepartamentoExpedicion")
    protected String departamentoExpedicion;
    @XmlElement(name = "EstadoCedula")
    protected String estadoCedula;
    @XmlElement(name = "FechaExpedicion")
    protected String fechaExpedicion;
    @XmlElement(name = "MunicipioExpedicion")
    protected String municipioExpedicion;
    @XmlElement(name = "NUIP")
    protected String nuip;
    @XmlElement(name = "NumeroResolucion")
    protected String numeroResolucion;
    @XmlElement(name = "Particula")
    protected String particula;
    @XmlElement(name = "PrimerApellido")
    protected String primerApellido;
    @XmlElement(name = "PrimerNombre")
    protected String primerNombre;
    @XmlElement(name = "SegundoApellido")
    protected String segundoApellido;
    @XmlElement(name = "SegundoNombre")
    protected String segundoNombre;

    /**
     * Obtiene el valor de la propiedad anioResolucion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnioResolucion() {
        return anioResolucion;
    }

    /**
     * Define el valor de la propiedad anioResolucion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnioResolucion(String value) {
        this.anioResolucion = value;
    }

    /**
     * Obtiene el valor de la propiedad codigoErrorDatosCedula.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoErrorDatosCedula() {
        return codigoErrorDatosCedula;
    }

    /**
     * Define el valor de la propiedad codigoErrorDatosCedula.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoErrorDatosCedula(String value) {
        this.codigoErrorDatosCedula = value;
    }

    /**
     * Obtiene el valor de la propiedad departamentoExpedicion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDepartamentoExpedicion() {
        return departamentoExpedicion;
    }

    /**
     * Define el valor de la propiedad departamentoExpedicion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDepartamentoExpedicion(String value) {
        this.departamentoExpedicion = value;
    }

    /**
     * Obtiene el valor de la propiedad estadoCedula.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEstadoCedula() {
        return estadoCedula;
    }

    /**
     * Define el valor de la propiedad estadoCedula.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEstadoCedula(String value) {
        this.estadoCedula = value;
    }

    /**
     * Obtiene el valor de la propiedad fechaExpedicion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFechaExpedicion() {
        return fechaExpedicion;
    }

    /**
     * Define el valor de la propiedad fechaExpedicion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFechaExpedicion(String value) {
        this.fechaExpedicion = value;
    }

    /**
     * Obtiene el valor de la propiedad municipioExpedicion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMunicipioExpedicion() {
        return municipioExpedicion;
    }

    /**
     * Define el valor de la propiedad municipioExpedicion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMunicipioExpedicion(String value) {
        this.municipioExpedicion = value;
    }

    /**
     * Obtiene el valor de la propiedad nuip.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNUIP() {
        return nuip;
    }

    /**
     * Define el valor de la propiedad nuip.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNUIP(String value) {
        this.nuip = value;
    }

    /**
     * Obtiene el valor de la propiedad numeroResolucion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroResolucion() {
        return numeroResolucion;
    }

    /**
     * Define el valor de la propiedad numeroResolucion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroResolucion(String value) {
        this.numeroResolucion = value;
    }

    /**
     * Obtiene el valor de la propiedad particula.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParticula() {
        return particula;
    }

    /**
     * Define el valor de la propiedad particula.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParticula(String value) {
        this.particula = value;
    }

    /**
     * Obtiene el valor de la propiedad primerApellido.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimerApellido() {
        return primerApellido;
    }

    /**
     * Define el valor de la propiedad primerApellido.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimerApellido(String value) {
        this.primerApellido = value;
    }

    /**
     * Obtiene el valor de la propiedad primerNombre.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimerNombre() {
        return primerNombre;
    }

    /**
     * Define el valor de la propiedad primerNombre.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimerNombre(String value) {
        this.primerNombre = value;
    }

    /**
     * Obtiene el valor de la propiedad segundoApellido.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSegundoApellido() {
        return segundoApellido;
    }

    /**
     * Define el valor de la propiedad segundoApellido.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSegundoApellido(String value) {
        this.segundoApellido = value;
    }

    /**
     * Obtiene el valor de la propiedad segundoNombre.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSegundoNombre() {
        return segundoNombre;
    }

    /**
     * Define el valor de la propiedad segundoNombre.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSegundoNombre(String value) {
        this.segundoNombre = value;
    }

}
