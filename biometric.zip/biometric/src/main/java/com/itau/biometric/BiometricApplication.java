package com.itau.biometric;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiometricApplication {

	public static void main(String[] args) {
		SpringApplication.run(BiometricApplication.class, args);
	}

}
