
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para ClienteDocumento complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ClienteDocumento">
 *   &lt;complexContent>
 *     &lt;extension base="{http://casb.bytte.com.co/}ClienteDocumentoData">
 *       &lt;sequence>
 *         &lt;element name="CldId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FechaRegistro" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="EnrolamientoFaceFecha" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="EnrolamientoFaceURL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EnrolamientoFaceTemplate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EnrolamientoFace" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClienteDocumento", propOrder = {
    "cldId",
    "fechaRegistro",
    "enrolamientoFaceFecha",
    "enrolamientoFaceURL",
    "enrolamientoFaceTemplate",
    "enrolamientoFace"
})
public class ClienteDocumento
    extends ClienteDocumentoData
{

    @XmlElement(name = "CldId")
    protected String cldId;
    @XmlElement(name = "FechaRegistro", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar fechaRegistro;
    @XmlElement(name = "EnrolamientoFaceFecha", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar enrolamientoFaceFecha;
    @XmlElement(name = "EnrolamientoFaceURL")
    protected String enrolamientoFaceURL;
    @XmlElement(name = "EnrolamientoFaceTemplate")
    protected String enrolamientoFaceTemplate;
    @XmlElement(name = "EnrolamientoFace")
    protected boolean enrolamientoFace;

    /**
     * Obtiene el valor de la propiedad cldId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCldId() {
        return cldId;
    }

    /**
     * Define el valor de la propiedad cldId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCldId(String value) {
        this.cldId = value;
    }

    /**
     * Obtiene el valor de la propiedad fechaRegistro.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFechaRegistro() {
        return fechaRegistro;
    }

    /**
     * Define el valor de la propiedad fechaRegistro.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechaRegistro(XMLGregorianCalendar value) {
        this.fechaRegistro = value;
    }

    /**
     * Obtiene el valor de la propiedad enrolamientoFaceFecha.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getEnrolamientoFaceFecha() {
        return enrolamientoFaceFecha;
    }

    /**
     * Define el valor de la propiedad enrolamientoFaceFecha.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setEnrolamientoFaceFecha(XMLGregorianCalendar value) {
        this.enrolamientoFaceFecha = value;
    }

    /**
     * Obtiene el valor de la propiedad enrolamientoFaceURL.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnrolamientoFaceURL() {
        return enrolamientoFaceURL;
    }

    /**
     * Define el valor de la propiedad enrolamientoFaceURL.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnrolamientoFaceURL(String value) {
        this.enrolamientoFaceURL = value;
    }

    /**
     * Obtiene el valor de la propiedad enrolamientoFaceTemplate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnrolamientoFaceTemplate() {
        return enrolamientoFaceTemplate;
    }

    /**
     * Define el valor de la propiedad enrolamientoFaceTemplate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnrolamientoFaceTemplate(String value) {
        this.enrolamientoFaceTemplate = value;
    }

    /**
     * Obtiene el valor de la propiedad enrolamientoFace.
     * 
     */
    public boolean isEnrolamientoFace() {
        return enrolamientoFace;
    }

    /**
     * Define el valor de la propiedad enrolamientoFace.
     * 
     */
    public void setEnrolamientoFace(boolean value) {
        this.enrolamientoFace = value;
    }

}
