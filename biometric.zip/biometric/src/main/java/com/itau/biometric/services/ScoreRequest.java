
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ScoreRequest complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ScoreRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Score_AutenticacionDactilar" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Score_ConANI_ANIOCR" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Score_ConANI_OCRBarCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Score_ConANI_ANIBarCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Score_ConANI_Fingerprint" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Score_SinANI_OCRBarCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Score_SinANI_Fingerprint" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Porcentaje_ConANI_AniOCR" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Porcentaje_ConANI_OCRBarcode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Porcentaje_ConANI_AniBarCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Porcentaje_ConANI_FaceMatch" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Porcentaje_SinANI_OCRBarcode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Porcentaje_SinAni_FaceMatch" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Porcentaje_General_Minimo" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Porcentaje_General_Minimo_AniOCR" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Porcentaje_General_Minimo_OCRBarcode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Porcentaje_General_Minimo_AniBarCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ScoreRequest", propOrder = {
    "scoreAutenticacionDactilar",
    "scoreConANIANIOCR",
    "scoreConANIOCRBarCode",
    "scoreConANIANIBarCode",
    "scoreConANIFingerprint",
    "scoreSinANIOCRBarCode",
    "scoreSinANIFingerprint",
    "porcentajeConANIAniOCR",
    "porcentajeConANIOCRBarcode",
    "porcentajeConANIAniBarCode",
    "porcentajeConANIFaceMatch",
    "porcentajeSinANIOCRBarcode",
    "porcentajeSinAniFaceMatch",
    "porcentajeGeneralMinimo",
    "porcentajeGeneralMinimoAniOCR",
    "porcentajeGeneralMinimoOCRBarcode",
    "porcentajeGeneralMinimoAniBarCode"
})
public class ScoreRequest {

    @XmlElement(name = "Score_AutenticacionDactilar")
    protected int scoreAutenticacionDactilar;
    @XmlElement(name = "Score_ConANI_ANIOCR")
    protected int scoreConANIANIOCR;
    @XmlElement(name = "Score_ConANI_OCRBarCode")
    protected int scoreConANIOCRBarCode;
    @XmlElement(name = "Score_ConANI_ANIBarCode")
    protected int scoreConANIANIBarCode;
    @XmlElement(name = "Score_ConANI_Fingerprint")
    protected int scoreConANIFingerprint;
    @XmlElement(name = "Score_SinANI_OCRBarCode")
    protected int scoreSinANIOCRBarCode;
    @XmlElement(name = "Score_SinANI_Fingerprint")
    protected int scoreSinANIFingerprint;
    @XmlElement(name = "Porcentaje_ConANI_AniOCR")
    protected int porcentajeConANIAniOCR;
    @XmlElement(name = "Porcentaje_ConANI_OCRBarcode")
    protected int porcentajeConANIOCRBarcode;
    @XmlElement(name = "Porcentaje_ConANI_AniBarCode")
    protected int porcentajeConANIAniBarCode;
    @XmlElement(name = "Porcentaje_ConANI_FaceMatch")
    protected int porcentajeConANIFaceMatch;
    @XmlElement(name = "Porcentaje_SinANI_OCRBarcode")
    protected int porcentajeSinANIOCRBarcode;
    @XmlElement(name = "Porcentaje_SinAni_FaceMatch")
    protected int porcentajeSinAniFaceMatch;
    @XmlElement(name = "Porcentaje_General_Minimo")
    protected int porcentajeGeneralMinimo;
    @XmlElement(name = "Porcentaje_General_Minimo_AniOCR")
    protected int porcentajeGeneralMinimoAniOCR;
    @XmlElement(name = "Porcentaje_General_Minimo_OCRBarcode")
    protected int porcentajeGeneralMinimoOCRBarcode;
    @XmlElement(name = "Porcentaje_General_Minimo_AniBarCode")
    protected int porcentajeGeneralMinimoAniBarCode;

    /**
     * Obtiene el valor de la propiedad scoreAutenticacionDactilar.
     * 
     */
    public int getScoreAutenticacionDactilar() {
        return scoreAutenticacionDactilar;
    }

    /**
     * Define el valor de la propiedad scoreAutenticacionDactilar.
     * 
     */
    public void setScoreAutenticacionDactilar(int value) {
        this.scoreAutenticacionDactilar = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreConANIANIOCR.
     * 
     */
    public int getScoreConANIANIOCR() {
        return scoreConANIANIOCR;
    }

    /**
     * Define el valor de la propiedad scoreConANIANIOCR.
     * 
     */
    public void setScoreConANIANIOCR(int value) {
        this.scoreConANIANIOCR = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreConANIOCRBarCode.
     * 
     */
    public int getScoreConANIOCRBarCode() {
        return scoreConANIOCRBarCode;
    }

    /**
     * Define el valor de la propiedad scoreConANIOCRBarCode.
     * 
     */
    public void setScoreConANIOCRBarCode(int value) {
        this.scoreConANIOCRBarCode = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreConANIANIBarCode.
     * 
     */
    public int getScoreConANIANIBarCode() {
        return scoreConANIANIBarCode;
    }

    /**
     * Define el valor de la propiedad scoreConANIANIBarCode.
     * 
     */
    public void setScoreConANIANIBarCode(int value) {
        this.scoreConANIANIBarCode = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreConANIFingerprint.
     * 
     */
    public int getScoreConANIFingerprint() {
        return scoreConANIFingerprint;
    }

    /**
     * Define el valor de la propiedad scoreConANIFingerprint.
     * 
     */
    public void setScoreConANIFingerprint(int value) {
        this.scoreConANIFingerprint = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreSinANIOCRBarCode.
     * 
     */
    public int getScoreSinANIOCRBarCode() {
        return scoreSinANIOCRBarCode;
    }

    /**
     * Define el valor de la propiedad scoreSinANIOCRBarCode.
     * 
     */
    public void setScoreSinANIOCRBarCode(int value) {
        this.scoreSinANIOCRBarCode = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreSinANIFingerprint.
     * 
     */
    public int getScoreSinANIFingerprint() {
        return scoreSinANIFingerprint;
    }

    /**
     * Define el valor de la propiedad scoreSinANIFingerprint.
     * 
     */
    public void setScoreSinANIFingerprint(int value) {
        this.scoreSinANIFingerprint = value;
    }

    /**
     * Obtiene el valor de la propiedad porcentajeConANIAniOCR.
     * 
     */
    public int getPorcentajeConANIAniOCR() {
        return porcentajeConANIAniOCR;
    }

    /**
     * Define el valor de la propiedad porcentajeConANIAniOCR.
     * 
     */
    public void setPorcentajeConANIAniOCR(int value) {
        this.porcentajeConANIAniOCR = value;
    }

    /**
     * Obtiene el valor de la propiedad porcentajeConANIOCRBarcode.
     * 
     */
    public int getPorcentajeConANIOCRBarcode() {
        return porcentajeConANIOCRBarcode;
    }

    /**
     * Define el valor de la propiedad porcentajeConANIOCRBarcode.
     * 
     */
    public void setPorcentajeConANIOCRBarcode(int value) {
        this.porcentajeConANIOCRBarcode = value;
    }

    /**
     * Obtiene el valor de la propiedad porcentajeConANIAniBarCode.
     * 
     */
    public int getPorcentajeConANIAniBarCode() {
        return porcentajeConANIAniBarCode;
    }

    /**
     * Define el valor de la propiedad porcentajeConANIAniBarCode.
     * 
     */
    public void setPorcentajeConANIAniBarCode(int value) {
        this.porcentajeConANIAniBarCode = value;
    }

    /**
     * Obtiene el valor de la propiedad porcentajeConANIFaceMatch.
     * 
     */
    public int getPorcentajeConANIFaceMatch() {
        return porcentajeConANIFaceMatch;
    }

    /**
     * Define el valor de la propiedad porcentajeConANIFaceMatch.
     * 
     */
    public void setPorcentajeConANIFaceMatch(int value) {
        this.porcentajeConANIFaceMatch = value;
    }

    /**
     * Obtiene el valor de la propiedad porcentajeSinANIOCRBarcode.
     * 
     */
    public int getPorcentajeSinANIOCRBarcode() {
        return porcentajeSinANIOCRBarcode;
    }

    /**
     * Define el valor de la propiedad porcentajeSinANIOCRBarcode.
     * 
     */
    public void setPorcentajeSinANIOCRBarcode(int value) {
        this.porcentajeSinANIOCRBarcode = value;
    }

    /**
     * Obtiene el valor de la propiedad porcentajeSinAniFaceMatch.
     * 
     */
    public int getPorcentajeSinAniFaceMatch() {
        return porcentajeSinAniFaceMatch;
    }

    /**
     * Define el valor de la propiedad porcentajeSinAniFaceMatch.
     * 
     */
    public void setPorcentajeSinAniFaceMatch(int value) {
        this.porcentajeSinAniFaceMatch = value;
    }

    /**
     * Obtiene el valor de la propiedad porcentajeGeneralMinimo.
     * 
     */
    public int getPorcentajeGeneralMinimo() {
        return porcentajeGeneralMinimo;
    }

    /**
     * Define el valor de la propiedad porcentajeGeneralMinimo.
     * 
     */
    public void setPorcentajeGeneralMinimo(int value) {
        this.porcentajeGeneralMinimo = value;
    }

    /**
     * Obtiene el valor de la propiedad porcentajeGeneralMinimoAniOCR.
     * 
     */
    public int getPorcentajeGeneralMinimoAniOCR() {
        return porcentajeGeneralMinimoAniOCR;
    }

    /**
     * Define el valor de la propiedad porcentajeGeneralMinimoAniOCR.
     * 
     */
    public void setPorcentajeGeneralMinimoAniOCR(int value) {
        this.porcentajeGeneralMinimoAniOCR = value;
    }

    /**
     * Obtiene el valor de la propiedad porcentajeGeneralMinimoOCRBarcode.
     * 
     */
    public int getPorcentajeGeneralMinimoOCRBarcode() {
        return porcentajeGeneralMinimoOCRBarcode;
    }

    /**
     * Define el valor de la propiedad porcentajeGeneralMinimoOCRBarcode.
     * 
     */
    public void setPorcentajeGeneralMinimoOCRBarcode(int value) {
        this.porcentajeGeneralMinimoOCRBarcode = value;
    }

    /**
     * Obtiene el valor de la propiedad porcentajeGeneralMinimoAniBarCode.
     * 
     */
    public int getPorcentajeGeneralMinimoAniBarCode() {
        return porcentajeGeneralMinimoAniBarCode;
    }

    /**
     * Define el valor de la propiedad porcentajeGeneralMinimoAniBarCode.
     * 
     */
    public void setPorcentajeGeneralMinimoAniBarCode(int value) {
        this.porcentajeGeneralMinimoAniBarCode = value;
    }

}
