
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para AutenticacionDactilarRequest complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="AutenticacionDactilarRequest">
 *   &lt;complexContent>
 *     &lt;extension base="{http://casb.bytte.com.co/}RequestBase">
 *       &lt;sequence>
 *         &lt;element name="HuellasProceso" type="{http://casb.bytte.com.co/}ArrayOfProcesoAutenticacionCapturaHuella" minOccurs="0"/>
 *         &lt;element name="ScoreRequerido" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="HuellasAProcesar" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AutenticacionDactilarRequest", propOrder = {
    "huellasProceso",
    "scoreRequerido",
    "huellasAProcesar"
})
public class AutenticacionDactilarRequest
    extends RequestBase
{

    @XmlElement(name = "HuellasProceso")
    protected ArrayOfProcesoAutenticacionCapturaHuella huellasProceso;
    @XmlElement(name = "ScoreRequerido")
    protected int scoreRequerido;
    @XmlElement(name = "HuellasAProcesar")
    protected int huellasAProcesar;

    /**
     * Obtiene el valor de la propiedad huellasProceso.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfProcesoAutenticacionCapturaHuella }
     *     
     */
    public ArrayOfProcesoAutenticacionCapturaHuella getHuellasProceso() {
        return huellasProceso;
    }

    /**
     * Define el valor de la propiedad huellasProceso.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfProcesoAutenticacionCapturaHuella }
     *     
     */
    public void setHuellasProceso(ArrayOfProcesoAutenticacionCapturaHuella value) {
        this.huellasProceso = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreRequerido.
     * 
     */
    public int getScoreRequerido() {
        return scoreRequerido;
    }

    /**
     * Define el valor de la propiedad scoreRequerido.
     * 
     */
    public void setScoreRequerido(int value) {
        this.scoreRequerido = value;
    }

    /**
     * Obtiene el valor de la propiedad huellasAProcesar.
     * 
     */
    public int getHuellasAProcesar() {
        return huellasAProcesar;
    }

    /**
     * Define el valor de la propiedad huellasAProcesar.
     * 
     */
    public void setHuellasAProcesar(int value) {
        this.huellasAProcesar = value;
    }

}
