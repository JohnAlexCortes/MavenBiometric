
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ValidacionEnrolamientoDocumentoRequest complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ValidacionEnrolamientoDocumentoRequest">
 *   &lt;complexContent>
 *     &lt;extension base="{http://casb.bytte.com.co/}RequestBase">
 *       &lt;sequence>
 *         &lt;element name="Completo" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="SoloMinucia" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="BarCodeBase64" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ImagenReverso" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="ImagenFrente" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="HuellasProceso" type="{http://casb.bytte.com.co/}ArrayOfProcesoAutenticacionCapturaHuella" minOccurs="0"/>
 *         &lt;element name="ScoreProceso" type="{http://casb.bytte.com.co/}ScoreRequest" minOccurs="0"/>
 *         &lt;element name="HuellasAProcesar" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValidacionEnrolamientoDocumentoRequest", propOrder = {
    "completo",
    "soloMinucia",
    "barCodeBase64",
    "imagenReverso",
    "imagenFrente",
    "huellasProceso",
    "scoreProceso",
    "huellasAProcesar"
})
@XmlSeeAlso({
    ValidacionEnrolamientoDocumentoRequestBase.class
})
public class ValidacionEnrolamientoDocumentoRequest
    extends RequestBase
{

    @XmlElement(name = "Completo")
    protected boolean completo;
    @XmlElement(name = "SoloMinucia")
    protected boolean soloMinucia;
    @XmlElement(name = "BarCodeBase64")
    protected String barCodeBase64;
    @XmlElement(name = "ImagenReverso")
    protected byte[] imagenReverso;
    @XmlElement(name = "ImagenFrente")
    protected byte[] imagenFrente;
    @XmlElement(name = "HuellasProceso")
    protected ArrayOfProcesoAutenticacionCapturaHuella huellasProceso;
    @XmlElement(name = "ScoreProceso")
    protected ScoreRequest scoreProceso;
    @XmlElement(name = "HuellasAProcesar")
    protected int huellasAProcesar;

    /**
     * Obtiene el valor de la propiedad completo.
     * 
     */
    public boolean isCompleto() {
        return completo;
    }

    /**
     * Define el valor de la propiedad completo.
     * 
     */
    public void setCompleto(boolean value) {
        this.completo = value;
    }

    /**
     * Obtiene el valor de la propiedad soloMinucia.
     * 
     */
    public boolean isSoloMinucia() {
        return soloMinucia;
    }

    /**
     * Define el valor de la propiedad soloMinucia.
     * 
     */
    public void setSoloMinucia(boolean value) {
        this.soloMinucia = value;
    }

    /**
     * Obtiene el valor de la propiedad barCodeBase64.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBarCodeBase64() {
        return barCodeBase64;
    }

    /**
     * Define el valor de la propiedad barCodeBase64.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBarCodeBase64(String value) {
        this.barCodeBase64 = value;
    }

    /**
     * Obtiene el valor de la propiedad imagenReverso.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getImagenReverso() {
        return imagenReverso;
    }

    /**
     * Define el valor de la propiedad imagenReverso.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setImagenReverso(byte[] value) {
        this.imagenReverso = value;
    }

    /**
     * Obtiene el valor de la propiedad imagenFrente.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getImagenFrente() {
        return imagenFrente;
    }

    /**
     * Define el valor de la propiedad imagenFrente.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setImagenFrente(byte[] value) {
        this.imagenFrente = value;
    }

    /**
     * Obtiene el valor de la propiedad huellasProceso.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfProcesoAutenticacionCapturaHuella }
     *     
     */
    public ArrayOfProcesoAutenticacionCapturaHuella getHuellasProceso() {
        return huellasProceso;
    }

    /**
     * Define el valor de la propiedad huellasProceso.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfProcesoAutenticacionCapturaHuella }
     *     
     */
    public void setHuellasProceso(ArrayOfProcesoAutenticacionCapturaHuella value) {
        this.huellasProceso = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreProceso.
     * 
     * @return
     *     possible object is
     *     {@link ScoreRequest }
     *     
     */
    public ScoreRequest getScoreProceso() {
        return scoreProceso;
    }

    /**
     * Define el valor de la propiedad scoreProceso.
     * 
     * @param value
     *     allowed object is
     *     {@link ScoreRequest }
     *     
     */
    public void setScoreProceso(ScoreRequest value) {
        this.scoreProceso = value;
    }

    /**
     * Obtiene el valor de la propiedad huellasAProcesar.
     * 
     */
    public int getHuellasAProcesar() {
        return huellasAProcesar;
    }

    /**
     * Define el valor de la propiedad huellasAProcesar.
     * 
     */
    public void setHuellasAProcesar(int value) {
        this.huellasAProcesar = value;
    }

}
