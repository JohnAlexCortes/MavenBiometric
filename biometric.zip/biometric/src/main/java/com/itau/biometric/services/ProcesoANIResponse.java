
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ProcesoANIResponse complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ProcesoANIResponse">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.bytte.com.co/}Response">
 *       &lt;sequence>
 *         &lt;element name="ANIInfo" type="{http://casb.bytte.com.co/}ANIData" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProcesoANIResponse", propOrder = {
    "aniInfo"
})
public class ProcesoANIResponse
    extends Response
{

    @XmlElement(name = "ANIInfo")
    protected ANIData aniInfo;

    /**
     * Obtiene el valor de la propiedad aniInfo.
     * 
     * @return
     *     possible object is
     *     {@link ANIData }
     *     
     */
    public ANIData getANIInfo() {
        return aniInfo;
    }

    /**
     * Define el valor de la propiedad aniInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link ANIData }
     *     
     */
    public void setANIInfo(ANIData value) {
        this.aniInfo = value;
    }

}
