
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ClienteDocumentoData complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ClienteDocumentoData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdTipoDocumento" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="NumeroDocumento" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NumeroPersonal" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Emisor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Codigo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FechaExpiracion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FechaNacimiento" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RH" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Nombres" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Apellidos" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Nacionalidad" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Sexo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Opt1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Opt2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Opt3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AlienNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicationNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ImmigrantNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Template" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TipoDedo1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TipoDedo2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NumeroTarjeta" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MRZ" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ImagenURL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClienteDocumentoData", propOrder = {
    "idTipoDocumento",
    "numeroDocumento",
    "numeroPersonal",
    "emisor",
    "codigo",
    "fechaExpiracion",
    "fechaNacimiento",
    "rh",
    "nombres",
    "apellidos",
    "nacionalidad",
    "sexo",
    "opt1",
    "opt2",
    "opt3",
    "alienNumber",
    "applicationNumber",
    "immigrantNumber",
    "version",
    "template",
    "tipoDedo1",
    "tipoDedo2",
    "numeroTarjeta",
    "mrz",
    "imagenURL"
})
@XmlSeeAlso({
    ClienteDocumento.class
})
public class ClienteDocumentoData {

    @XmlElement(name = "IdTipoDocumento")
    protected int idTipoDocumento;
    @XmlElement(name = "NumeroDocumento")
    protected String numeroDocumento;
    @XmlElement(name = "NumeroPersonal")
    protected String numeroPersonal;
    @XmlElement(name = "Emisor")
    protected String emisor;
    @XmlElement(name = "Codigo")
    protected String codigo;
    @XmlElement(name = "FechaExpiracion")
    protected String fechaExpiracion;
    @XmlElement(name = "FechaNacimiento")
    protected String fechaNacimiento;
    @XmlElement(name = "RH")
    protected String rh;
    @XmlElement(name = "Nombres")
    protected String nombres;
    @XmlElement(name = "Apellidos")
    protected String apellidos;
    @XmlElement(name = "Nacionalidad")
    protected String nacionalidad;
    @XmlElement(name = "Sexo")
    protected String sexo;
    @XmlElement(name = "Opt1")
    protected String opt1;
    @XmlElement(name = "Opt2")
    protected String opt2;
    @XmlElement(name = "Opt3")
    protected String opt3;
    @XmlElement(name = "AlienNumber")
    protected String alienNumber;
    @XmlElement(name = "ApplicationNumber")
    protected String applicationNumber;
    @XmlElement(name = "ImmigrantNumber")
    protected String immigrantNumber;
    @XmlElement(name = "Version")
    protected String version;
    @XmlElement(name = "Template")
    protected String template;
    @XmlElement(name = "TipoDedo1")
    protected String tipoDedo1;
    @XmlElement(name = "TipoDedo2")
    protected String tipoDedo2;
    @XmlElement(name = "NumeroTarjeta")
    protected String numeroTarjeta;
    @XmlElement(name = "MRZ")
    protected String mrz;
    @XmlElement(name = "ImagenURL")
    protected String imagenURL;

    /**
     * Obtiene el valor de la propiedad idTipoDocumento.
     * 
     */
    public int getIdTipoDocumento() {
        return idTipoDocumento;
    }

    /**
     * Define el valor de la propiedad idTipoDocumento.
     * 
     */
    public void setIdTipoDocumento(int value) {
        this.idTipoDocumento = value;
    }

    /**
     * Obtiene el valor de la propiedad numeroDocumento.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    /**
     * Define el valor de la propiedad numeroDocumento.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroDocumento(String value) {
        this.numeroDocumento = value;
    }

    /**
     * Obtiene el valor de la propiedad numeroPersonal.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroPersonal() {
        return numeroPersonal;
    }

    /**
     * Define el valor de la propiedad numeroPersonal.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroPersonal(String value) {
        this.numeroPersonal = value;
    }

    /**
     * Obtiene el valor de la propiedad emisor.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmisor() {
        return emisor;
    }

    /**
     * Define el valor de la propiedad emisor.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmisor(String value) {
        this.emisor = value;
    }

    /**
     * Obtiene el valor de la propiedad codigo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * Define el valor de la propiedad codigo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigo(String value) {
        this.codigo = value;
    }

    /**
     * Obtiene el valor de la propiedad fechaExpiracion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFechaExpiracion() {
        return fechaExpiracion;
    }

    /**
     * Define el valor de la propiedad fechaExpiracion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFechaExpiracion(String value) {
        this.fechaExpiracion = value;
    }

    /**
     * Obtiene el valor de la propiedad fechaNacimiento.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    /**
     * Define el valor de la propiedad fechaNacimiento.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFechaNacimiento(String value) {
        this.fechaNacimiento = value;
    }

    /**
     * Obtiene el valor de la propiedad rh.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRH() {
        return rh;
    }

    /**
     * Define el valor de la propiedad rh.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRH(String value) {
        this.rh = value;
    }

    /**
     * Obtiene el valor de la propiedad nombres.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNombres() {
        return nombres;
    }

    /**
     * Define el valor de la propiedad nombres.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNombres(String value) {
        this.nombres = value;
    }

    /**
     * Obtiene el valor de la propiedad apellidos.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApellidos() {
        return apellidos;
    }

    /**
     * Define el valor de la propiedad apellidos.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApellidos(String value) {
        this.apellidos = value;
    }

    /**
     * Obtiene el valor de la propiedad nacionalidad.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNacionalidad() {
        return nacionalidad;
    }

    /**
     * Define el valor de la propiedad nacionalidad.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNacionalidad(String value) {
        this.nacionalidad = value;
    }

    /**
     * Obtiene el valor de la propiedad sexo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSexo() {
        return sexo;
    }

    /**
     * Define el valor de la propiedad sexo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSexo(String value) {
        this.sexo = value;
    }

    /**
     * Obtiene el valor de la propiedad opt1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpt1() {
        return opt1;
    }

    /**
     * Define el valor de la propiedad opt1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpt1(String value) {
        this.opt1 = value;
    }

    /**
     * Obtiene el valor de la propiedad opt2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpt2() {
        return opt2;
    }

    /**
     * Define el valor de la propiedad opt2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpt2(String value) {
        this.opt2 = value;
    }

    /**
     * Obtiene el valor de la propiedad opt3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpt3() {
        return opt3;
    }

    /**
     * Define el valor de la propiedad opt3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpt3(String value) {
        this.opt3 = value;
    }

    /**
     * Obtiene el valor de la propiedad alienNumber.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlienNumber() {
        return alienNumber;
    }

    /**
     * Define el valor de la propiedad alienNumber.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlienNumber(String value) {
        this.alienNumber = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationNumber.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationNumber() {
        return applicationNumber;
    }

    /**
     * Define el valor de la propiedad applicationNumber.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationNumber(String value) {
        this.applicationNumber = value;
    }

    /**
     * Obtiene el valor de la propiedad immigrantNumber.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImmigrantNumber() {
        return immigrantNumber;
    }

    /**
     * Define el valor de la propiedad immigrantNumber.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImmigrantNumber(String value) {
        this.immigrantNumber = value;
    }

    /**
     * Obtiene el valor de la propiedad version.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersion() {
        return version;
    }

    /**
     * Define el valor de la propiedad version.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersion(String value) {
        this.version = value;
    }

    /**
     * Obtiene el valor de la propiedad template.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemplate() {
        return template;
    }

    /**
     * Define el valor de la propiedad template.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemplate(String value) {
        this.template = value;
    }

    /**
     * Obtiene el valor de la propiedad tipoDedo1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoDedo1() {
        return tipoDedo1;
    }

    /**
     * Define el valor de la propiedad tipoDedo1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoDedo1(String value) {
        this.tipoDedo1 = value;
    }

    /**
     * Obtiene el valor de la propiedad tipoDedo2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoDedo2() {
        return tipoDedo2;
    }

    /**
     * Define el valor de la propiedad tipoDedo2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoDedo2(String value) {
        this.tipoDedo2 = value;
    }

    /**
     * Obtiene el valor de la propiedad numeroTarjeta.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroTarjeta() {
        return numeroTarjeta;
    }

    /**
     * Define el valor de la propiedad numeroTarjeta.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroTarjeta(String value) {
        this.numeroTarjeta = value;
    }

    /**
     * Obtiene el valor de la propiedad mrz.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMRZ() {
        return mrz;
    }

    /**
     * Define el valor de la propiedad mrz.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMRZ(String value) {
        this.mrz = value;
    }

    /**
     * Obtiene el valor de la propiedad imagenURL.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImagenURL() {
        return imagenURL;
    }

    /**
     * Define el valor de la propiedad imagenURL.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImagenURL(String value) {
        this.imagenURL = value;
    }

}
