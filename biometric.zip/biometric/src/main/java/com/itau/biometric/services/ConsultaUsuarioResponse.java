
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ConsultaUsuarioResult" type="{http://casb.bytte.com.co/}UsuarioResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "consultaUsuarioResult"
})
@XmlRootElement(name = "ConsultaUsuarioResponse")
public class ConsultaUsuarioResponse {

    @XmlElement(name = "ConsultaUsuarioResult")
    protected UsuarioResponse consultaUsuarioResult;

    /**
     * Obtiene el valor de la propiedad consultaUsuarioResult.
     * 
     * @return
     *     possible object is
     *     {@link UsuarioResponse }
     *     
     */
    public UsuarioResponse getConsultaUsuarioResult() {
        return consultaUsuarioResult;
    }

    /**
     * Define el valor de la propiedad consultaUsuarioResult.
     * 
     * @param value
     *     allowed object is
     *     {@link UsuarioResponse }
     *     
     */
    public void setConsultaUsuarioResult(UsuarioResponse value) {
        this.consultaUsuarioResult = value;
    }

}
