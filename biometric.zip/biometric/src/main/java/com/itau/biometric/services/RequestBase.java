
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para RequestBase complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="RequestBase">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentificadorConsumidor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IdentificadorProceso" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ImageKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NumeroDocumento" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RequestBase", propOrder = {
    "identificadorConsumidor",
    "identificadorProceso",
    "imageKey",
    "numeroDocumento"
})
@XmlSeeAlso({
    ValidacionEnrolamientoDocumentoRequest.class,
    AutenticacionDactilarRequest.class
})
public class RequestBase {

    @XmlElement(name = "IdentificadorConsumidor")
    protected String identificadorConsumidor;
    @XmlElement(name = "IdentificadorProceso")
    protected String identificadorProceso;
    @XmlElement(name = "ImageKey")
    protected String imageKey;
    @XmlElement(name = "NumeroDocumento")
    protected String numeroDocumento;

    /**
     * Obtiene el valor de la propiedad identificadorConsumidor.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentificadorConsumidor() {
        return identificadorConsumidor;
    }

    /**
     * Define el valor de la propiedad identificadorConsumidor.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentificadorConsumidor(String value) {
        this.identificadorConsumidor = value;
    }

    /**
     * Obtiene el valor de la propiedad identificadorProceso.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentificadorProceso() {
        return identificadorProceso;
    }

    /**
     * Define el valor de la propiedad identificadorProceso.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentificadorProceso(String value) {
        this.identificadorProceso = value;
    }

    /**
     * Obtiene el valor de la propiedad imageKey.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImageKey() {
        return imageKey;
    }

    /**
     * Define el valor de la propiedad imageKey.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImageKey(String value) {
        this.imageKey = value;
    }

    /**
     * Obtiene el valor de la propiedad numeroDocumento.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    /**
     * Define el valor de la propiedad numeroDocumento.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroDocumento(String value) {
        this.numeroDocumento = value;
    }

}
