
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para UsuarioEnrolamiento complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="UsuarioEnrolamiento">
 *   &lt;complexContent>
 *     &lt;extension base="{http://casb.bytte.com.co/}Usuario">
 *       &lt;sequence>
 *         &lt;element name="EnroladoDactilar" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="TemplateDactilar" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EnroladoFacial" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="TemplateFacial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UsuarioEnrolamiento", propOrder = {
    "enroladoDactilar",
    "templateDactilar",
    "enroladoFacial",
    "templateFacial"
})
public class UsuarioEnrolamiento
    extends Usuario
{

    @XmlElement(name = "EnroladoDactilar")
    protected boolean enroladoDactilar;
    @XmlElement(name = "TemplateDactilar")
    protected String templateDactilar;
    @XmlElement(name = "EnroladoFacial")
    protected boolean enroladoFacial;
    @XmlElement(name = "TemplateFacial")
    protected String templateFacial;

    /**
     * Obtiene el valor de la propiedad enroladoDactilar.
     * 
     */
    public boolean isEnroladoDactilar() {
        return enroladoDactilar;
    }

    /**
     * Define el valor de la propiedad enroladoDactilar.
     * 
     */
    public void setEnroladoDactilar(boolean value) {
        this.enroladoDactilar = value;
    }

    /**
     * Obtiene el valor de la propiedad templateDactilar.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemplateDactilar() {
        return templateDactilar;
    }

    /**
     * Define el valor de la propiedad templateDactilar.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemplateDactilar(String value) {
        this.templateDactilar = value;
    }

    /**
     * Obtiene el valor de la propiedad enroladoFacial.
     * 
     */
    public boolean isEnroladoFacial() {
        return enroladoFacial;
    }

    /**
     * Define el valor de la propiedad enroladoFacial.
     * 
     */
    public void setEnroladoFacial(boolean value) {
        this.enroladoFacial = value;
    }

    /**
     * Obtiene el valor de la propiedad templateFacial.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemplateFacial() {
        return templateFacial;
    }

    /**
     * Define el valor de la propiedad templateFacial.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemplateFacial(String value) {
        this.templateFacial = value;
    }

}
