
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ConsultaProcesoValidacionDocumentoRequest complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ConsultaProcesoValidacionDocumentoRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentificadorProceso" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ConsultaImagenes" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="ConsultaInfoCodigoBarras" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="ConsultaHuellas" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="ConsultaScore" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsultaProcesoValidacionDocumentoRequest", propOrder = {
    "identificadorProceso",
    "consultaImagenes",
    "consultaInfoCodigoBarras",
    "consultaHuellas",
    "consultaScore"
})
public class ConsultaProcesoValidacionDocumentoRequest {

    @XmlElement(name = "IdentificadorProceso")
    protected String identificadorProceso;
    @XmlElement(name = "ConsultaImagenes")
    protected boolean consultaImagenes;
    @XmlElement(name = "ConsultaInfoCodigoBarras")
    protected boolean consultaInfoCodigoBarras;
    @XmlElement(name = "ConsultaHuellas")
    protected boolean consultaHuellas;
    @XmlElement(name = "ConsultaScore")
    protected boolean consultaScore;

    /**
     * Obtiene el valor de la propiedad identificadorProceso.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentificadorProceso() {
        return identificadorProceso;
    }

    /**
     * Define el valor de la propiedad identificadorProceso.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentificadorProceso(String value) {
        this.identificadorProceso = value;
    }

    /**
     * Obtiene el valor de la propiedad consultaImagenes.
     * 
     */
    public boolean isConsultaImagenes() {
        return consultaImagenes;
    }

    /**
     * Define el valor de la propiedad consultaImagenes.
     * 
     */
    public void setConsultaImagenes(boolean value) {
        this.consultaImagenes = value;
    }

    /**
     * Obtiene el valor de la propiedad consultaInfoCodigoBarras.
     * 
     */
    public boolean isConsultaInfoCodigoBarras() {
        return consultaInfoCodigoBarras;
    }

    /**
     * Define el valor de la propiedad consultaInfoCodigoBarras.
     * 
     */
    public void setConsultaInfoCodigoBarras(boolean value) {
        this.consultaInfoCodigoBarras = value;
    }

    /**
     * Obtiene el valor de la propiedad consultaHuellas.
     * 
     */
    public boolean isConsultaHuellas() {
        return consultaHuellas;
    }

    /**
     * Define el valor de la propiedad consultaHuellas.
     * 
     */
    public void setConsultaHuellas(boolean value) {
        this.consultaHuellas = value;
    }

    /**
     * Obtiene el valor de la propiedad consultaScore.
     * 
     */
    public boolean isConsultaScore() {
        return consultaScore;
    }

    /**
     * Define el valor de la propiedad consultaScore.
     * 
     */
    public void setConsultaScore(boolean value) {
        this.consultaScore = value;
    }

}
