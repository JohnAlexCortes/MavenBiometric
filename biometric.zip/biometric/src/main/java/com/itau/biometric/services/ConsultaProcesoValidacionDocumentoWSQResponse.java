
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ConsultaProcesoValidacionDocumentoWSQResult" type="{http://casb.bytte.com.co/}ProcesoAutenticacionLogResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "consultaProcesoValidacionDocumentoWSQResult"
})
@XmlRootElement(name = "ConsultaProcesoValidacionDocumentoWSQResponse")
public class ConsultaProcesoValidacionDocumentoWSQResponse {

    @XmlElement(name = "ConsultaProcesoValidacionDocumentoWSQResult")
    protected ProcesoAutenticacionLogResponse consultaProcesoValidacionDocumentoWSQResult;

    /**
     * Obtiene el valor de la propiedad consultaProcesoValidacionDocumentoWSQResult.
     * 
     * @return
     *     possible object is
     *     {@link ProcesoAutenticacionLogResponse }
     *     
     */
    public ProcesoAutenticacionLogResponse getConsultaProcesoValidacionDocumentoWSQResult() {
        return consultaProcesoValidacionDocumentoWSQResult;
    }

    /**
     * Define el valor de la propiedad consultaProcesoValidacionDocumentoWSQResult.
     * 
     * @param value
     *     allowed object is
     *     {@link ProcesoAutenticacionLogResponse }
     *     
     */
    public void setConsultaProcesoValidacionDocumentoWSQResult(ProcesoAutenticacionLogResponse value) {
        this.consultaProcesoValidacionDocumentoWSQResult = value;
    }

}
