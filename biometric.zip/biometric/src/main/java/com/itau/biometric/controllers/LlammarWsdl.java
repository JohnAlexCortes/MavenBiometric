package com.itau.biometric.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.itau.biometric.services.Calculator;
import com.itau.biometric.services.CalculatorSoap;
import com.itau.biometric.services.IServicioAutenticacion;
import com.itau.biometric.services.ServicioAutenticacion;


@RestController
@RequestMapping("/llamarWsdl")
public class LlammarWsdl {
	
	private static final Logger log= LoggerFactory.getLogger(LlammarWsdl.class);
	
	 @RequestMapping("/Wsdl")
	 public void llamar()
	 {
		 log.info("---Inicio uuuuu-------->>>");
		 CalculatorSoap servicio2 = new  Calculator().getCalculatorSoap();
		 IServicioAutenticacion servicio = new ServicioAutenticacion().getCASBProcesoAutenticacionService();
		 log.info("---Inicio ppppp-------->>>");
		 
		 try 
		 {
			 servicio2.add(1, 2);
			 servicio.consultaUsuario("78787878");
			 log.info("---Inicio-------->>>");
		 } catch (Exception e) {
			 log.info("---Error-------->>>" + e.getMessage());
		 }
		 
		 
	 }

}
