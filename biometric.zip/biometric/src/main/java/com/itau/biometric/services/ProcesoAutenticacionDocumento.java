
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ProcesoAutenticacionDocumento complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ProcesoAutenticacionDocumento">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ImagenFrente" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="URLImagenFrente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ImagenReverso" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="URLImagenReverso" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProcesoAutenticacionDocumento", propOrder = {
    "imagenFrente",
    "urlImagenFrente",
    "imagenReverso",
    "urlImagenReverso"
})
public class ProcesoAutenticacionDocumento {

    @XmlElement(name = "ImagenFrente")
    protected byte[] imagenFrente;
    @XmlElement(name = "URLImagenFrente")
    protected String urlImagenFrente;
    @XmlElement(name = "ImagenReverso")
    protected byte[] imagenReverso;
    @XmlElement(name = "URLImagenReverso")
    protected String urlImagenReverso;

    /**
     * Obtiene el valor de la propiedad imagenFrente.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getImagenFrente() {
        return imagenFrente;
    }

    /**
     * Define el valor de la propiedad imagenFrente.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setImagenFrente(byte[] value) {
        this.imagenFrente = value;
    }

    /**
     * Obtiene el valor de la propiedad urlImagenFrente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getURLImagenFrente() {
        return urlImagenFrente;
    }

    /**
     * Define el valor de la propiedad urlImagenFrente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setURLImagenFrente(String value) {
        this.urlImagenFrente = value;
    }

    /**
     * Obtiene el valor de la propiedad imagenReverso.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getImagenReverso() {
        return imagenReverso;
    }

    /**
     * Define el valor de la propiedad imagenReverso.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setImagenReverso(byte[] value) {
        this.imagenReverso = value;
    }

    /**
     * Obtiene el valor de la propiedad urlImagenReverso.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getURLImagenReverso() {
        return urlImagenReverso;
    }

    /**
     * Define el valor de la propiedad urlImagenReverso.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setURLImagenReverso(String value) {
        this.urlImagenReverso = value;
    }

}
