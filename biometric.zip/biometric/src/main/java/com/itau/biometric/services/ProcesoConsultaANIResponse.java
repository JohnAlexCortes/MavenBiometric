
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ProcesoConsultaANIResult" type="{http://casb.bytte.com.co/}ProcesoANIResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "procesoConsultaANIResult"
})
@XmlRootElement(name = "ProcesoConsultaANIResponse")
public class ProcesoConsultaANIResponse {

    @XmlElement(name = "ProcesoConsultaANIResult")
    protected ProcesoANIResponse procesoConsultaANIResult;

    /**
     * Obtiene el valor de la propiedad procesoConsultaANIResult.
     * 
     * @return
     *     possible object is
     *     {@link ProcesoANIResponse }
     *     
     */
    public ProcesoANIResponse getProcesoConsultaANIResult() {
        return procesoConsultaANIResult;
    }

    /**
     * Define el valor de la propiedad procesoConsultaANIResult.
     * 
     * @param value
     *     allowed object is
     *     {@link ProcesoANIResponse }
     *     
     */
    public void setProcesoConsultaANIResult(ProcesoANIResponse value) {
        this.procesoConsultaANIResult = value;
    }

}
