
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para Response complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="Response">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="OperacionExitosa" use="required" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="Mensaje" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="MensajeOperacion" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Response", namespace = "http://www.bytte.com.co/")
@XmlSeeAlso({
    ProcesoAutenticacionLogResponse.class,
    ProcesoANIResponse.class,
    ProcesoValidacionDocumentoResponse.class,
    ConvertClienteResponse.class,
    UsuarioResponse.class,
    ANIResponse.class
})
public class Response {

    @XmlAttribute(name = "OperacionExitosa", required = true)
    protected boolean operacionExitosa;
    @XmlAttribute(name = "Mensaje")
    protected String mensaje;
    @XmlAttribute(name = "MensajeOperacion")
    protected String mensajeOperacion;

    /**
     * Obtiene el valor de la propiedad operacionExitosa.
     * 
     */
    public boolean isOperacionExitosa() {
        return operacionExitosa;
    }

    /**
     * Define el valor de la propiedad operacionExitosa.
     * 
     */
    public void setOperacionExitosa(boolean value) {
        this.operacionExitosa = value;
    }

    /**
     * Obtiene el valor de la propiedad mensaje.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMensaje() {
        return mensaje;
    }

    /**
     * Define el valor de la propiedad mensaje.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMensaje(String value) {
        this.mensaje = value;
    }

    /**
     * Obtiene el valor de la propiedad mensajeOperacion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMensajeOperacion() {
        return mensajeOperacion;
    }

    /**
     * Define el valor de la propiedad mensajeOperacion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMensajeOperacion(String value) {
        this.mensajeOperacion = value;
    }

}
