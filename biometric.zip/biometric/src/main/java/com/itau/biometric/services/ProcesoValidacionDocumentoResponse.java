
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ProcesoValidacionDocumentoResponse complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ProcesoValidacionDocumentoResponse">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.bytte.com.co/}Response">
 *       &lt;sequence>
 *         &lt;element name="ScoreDactilar" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ScoreDactilarValor" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ScoreANIOCR" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ScoreANIBarCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ScoreOCRBarCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ScoreFace" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ScoreFaceValor" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ScoreDocumento" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="StatusDactilar" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="StatusANIOCR" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="StatusANIBarCode" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="StatusOCRBarCode" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="StatusFace" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="StatusDocumento" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="AutenticadoDocumento" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InformacionCliente" type="{http://casb.bytte.com.co/}ClienteDocumento" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProcesoValidacionDocumentoResponse", propOrder = {
    "scoreDactilar",
    "scoreDactilarValor",
    "scoreANIOCR",
    "scoreANIBarCode",
    "scoreOCRBarCode",
    "scoreFace",
    "scoreFaceValor",
    "scoreDocumento",
    "statusDactilar",
    "statusANIOCR",
    "statusANIBarCode",
    "statusOCRBarCode",
    "statusFace",
    "statusDocumento",
    "autenticadoDocumento",
    "informacionCliente"
})
public class ProcesoValidacionDocumentoResponse
    extends Response
{

    @XmlElement(name = "ScoreDactilar")
    protected int scoreDactilar;
    @XmlElement(name = "ScoreDactilarValor")
    protected int scoreDactilarValor;
    @XmlElement(name = "ScoreANIOCR")
    protected int scoreANIOCR;
    @XmlElement(name = "ScoreANIBarCode")
    protected int scoreANIBarCode;
    @XmlElement(name = "ScoreOCRBarCode")
    protected int scoreOCRBarCode;
    @XmlElement(name = "ScoreFace")
    protected int scoreFace;
    @XmlElement(name = "ScoreFaceValor")
    protected int scoreFaceValor;
    @XmlElement(name = "ScoreDocumento")
    protected int scoreDocumento;
    @XmlElement(name = "StatusDactilar")
    protected short statusDactilar;
    @XmlElement(name = "StatusANIOCR")
    protected short statusANIOCR;
    @XmlElement(name = "StatusANIBarCode")
    protected short statusANIBarCode;
    @XmlElement(name = "StatusOCRBarCode")
    protected short statusOCRBarCode;
    @XmlElement(name = "StatusFace")
    protected short statusFace;
    @XmlElement(name = "StatusDocumento")
    protected short statusDocumento;
    @XmlElement(name = "AutenticadoDocumento")
    protected boolean autenticadoDocumento;
    @XmlElement(name = "InformacionCliente")
    protected ClienteDocumento informacionCliente;

    /**
     * Obtiene el valor de la propiedad scoreDactilar.
     * 
     */
    public int getScoreDactilar() {
        return scoreDactilar;
    }

    /**
     * Define el valor de la propiedad scoreDactilar.
     * 
     */
    public void setScoreDactilar(int value) {
        this.scoreDactilar = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreDactilarValor.
     * 
     */
    public int getScoreDactilarValor() {
        return scoreDactilarValor;
    }

    /**
     * Define el valor de la propiedad scoreDactilarValor.
     * 
     */
    public void setScoreDactilarValor(int value) {
        this.scoreDactilarValor = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreANIOCR.
     * 
     */
    public int getScoreANIOCR() {
        return scoreANIOCR;
    }

    /**
     * Define el valor de la propiedad scoreANIOCR.
     * 
     */
    public void setScoreANIOCR(int value) {
        this.scoreANIOCR = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreANIBarCode.
     * 
     */
    public int getScoreANIBarCode() {
        return scoreANIBarCode;
    }

    /**
     * Define el valor de la propiedad scoreANIBarCode.
     * 
     */
    public void setScoreANIBarCode(int value) {
        this.scoreANIBarCode = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreOCRBarCode.
     * 
     */
    public int getScoreOCRBarCode() {
        return scoreOCRBarCode;
    }

    /**
     * Define el valor de la propiedad scoreOCRBarCode.
     * 
     */
    public void setScoreOCRBarCode(int value) {
        this.scoreOCRBarCode = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreFace.
     * 
     */
    public int getScoreFace() {
        return scoreFace;
    }

    /**
     * Define el valor de la propiedad scoreFace.
     * 
     */
    public void setScoreFace(int value) {
        this.scoreFace = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreFaceValor.
     * 
     */
    public int getScoreFaceValor() {
        return scoreFaceValor;
    }

    /**
     * Define el valor de la propiedad scoreFaceValor.
     * 
     */
    public void setScoreFaceValor(int value) {
        this.scoreFaceValor = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreDocumento.
     * 
     */
    public int getScoreDocumento() {
        return scoreDocumento;
    }

    /**
     * Define el valor de la propiedad scoreDocumento.
     * 
     */
    public void setScoreDocumento(int value) {
        this.scoreDocumento = value;
    }

    /**
     * Obtiene el valor de la propiedad statusDactilar.
     * 
     */
    public short getStatusDactilar() {
        return statusDactilar;
    }

    /**
     * Define el valor de la propiedad statusDactilar.
     * 
     */
    public void setStatusDactilar(short value) {
        this.statusDactilar = value;
    }

    /**
     * Obtiene el valor de la propiedad statusANIOCR.
     * 
     */
    public short getStatusANIOCR() {
        return statusANIOCR;
    }

    /**
     * Define el valor de la propiedad statusANIOCR.
     * 
     */
    public void setStatusANIOCR(short value) {
        this.statusANIOCR = value;
    }

    /**
     * Obtiene el valor de la propiedad statusANIBarCode.
     * 
     */
    public short getStatusANIBarCode() {
        return statusANIBarCode;
    }

    /**
     * Define el valor de la propiedad statusANIBarCode.
     * 
     */
    public void setStatusANIBarCode(short value) {
        this.statusANIBarCode = value;
    }

    /**
     * Obtiene el valor de la propiedad statusOCRBarCode.
     * 
     */
    public short getStatusOCRBarCode() {
        return statusOCRBarCode;
    }

    /**
     * Define el valor de la propiedad statusOCRBarCode.
     * 
     */
    public void setStatusOCRBarCode(short value) {
        this.statusOCRBarCode = value;
    }

    /**
     * Obtiene el valor de la propiedad statusFace.
     * 
     */
    public short getStatusFace() {
        return statusFace;
    }

    /**
     * Define el valor de la propiedad statusFace.
     * 
     */
    public void setStatusFace(short value) {
        this.statusFace = value;
    }

    /**
     * Obtiene el valor de la propiedad statusDocumento.
     * 
     */
    public short getStatusDocumento() {
        return statusDocumento;
    }

    /**
     * Define el valor de la propiedad statusDocumento.
     * 
     */
    public void setStatusDocumento(short value) {
        this.statusDocumento = value;
    }

    /**
     * Obtiene el valor de la propiedad autenticadoDocumento.
     * 
     */
    public boolean isAutenticadoDocumento() {
        return autenticadoDocumento;
    }

    /**
     * Define el valor de la propiedad autenticadoDocumento.
     * 
     */
    public void setAutenticadoDocumento(boolean value) {
        this.autenticadoDocumento = value;
    }

    /**
     * Obtiene el valor de la propiedad informacionCliente.
     * 
     * @return
     *     possible object is
     *     {@link ClienteDocumento }
     *     
     */
    public ClienteDocumento getInformacionCliente() {
        return informacionCliente;
    }

    /**
     * Define el valor de la propiedad informacionCliente.
     * 
     * @param value
     *     allowed object is
     *     {@link ClienteDocumento }
     *     
     */
    public void setInformacionCliente(ClienteDocumento value) {
        this.informacionCliente = value;
    }

}
