
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ValidacionEnrolamientoDocumentoRequestBase complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ValidacionEnrolamientoDocumentoRequestBase">
 *   &lt;complexContent>
 *     &lt;extension base="{http://casb.bytte.com.co/}ValidacionEnrolamientoDocumentoRequest">
 *       &lt;sequence>
 *         &lt;element name="GPSData" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DeviceIP" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DeviceMAC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DeviceUUID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ImagenFrenteRostro" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="ImagenSelfie" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="ImagenFrenteFirma" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="ImagenCompleta" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValidacionEnrolamientoDocumentoRequestBase", propOrder = {
    "gpsData",
    "deviceIP",
    "deviceMAC",
    "deviceUUID",
    "imagenFrenteRostro",
    "imagenSelfie",
    "imagenFrenteFirma",
    "imagenCompleta"
})
public class ValidacionEnrolamientoDocumentoRequestBase
    extends ValidacionEnrolamientoDocumentoRequest
{

    @XmlElement(name = "GPSData")
    protected String gpsData;
    @XmlElement(name = "DeviceIP")
    protected String deviceIP;
    @XmlElement(name = "DeviceMAC")
    protected String deviceMAC;
    @XmlElement(name = "DeviceUUID")
    protected String deviceUUID;
    @XmlElement(name = "ImagenFrenteRostro")
    protected byte[] imagenFrenteRostro;
    @XmlElement(name = "ImagenSelfie")
    protected byte[] imagenSelfie;
    @XmlElement(name = "ImagenFrenteFirma")
    protected byte[] imagenFrenteFirma;
    @XmlElement(name = "ImagenCompleta")
    protected byte[] imagenCompleta;

    /**
     * Obtiene el valor de la propiedad gpsData.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGPSData() {
        return gpsData;
    }

    /**
     * Define el valor de la propiedad gpsData.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGPSData(String value) {
        this.gpsData = value;
    }

    /**
     * Obtiene el valor de la propiedad deviceIP.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceIP() {
        return deviceIP;
    }

    /**
     * Define el valor de la propiedad deviceIP.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceIP(String value) {
        this.deviceIP = value;
    }

    /**
     * Obtiene el valor de la propiedad deviceMAC.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceMAC() {
        return deviceMAC;
    }

    /**
     * Define el valor de la propiedad deviceMAC.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceMAC(String value) {
        this.deviceMAC = value;
    }

    /**
     * Obtiene el valor de la propiedad deviceUUID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceUUID() {
        return deviceUUID;
    }

    /**
     * Define el valor de la propiedad deviceUUID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceUUID(String value) {
        this.deviceUUID = value;
    }

    /**
     * Obtiene el valor de la propiedad imagenFrenteRostro.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getImagenFrenteRostro() {
        return imagenFrenteRostro;
    }

    /**
     * Define el valor de la propiedad imagenFrenteRostro.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setImagenFrenteRostro(byte[] value) {
        this.imagenFrenteRostro = value;
    }

    /**
     * Obtiene el valor de la propiedad imagenSelfie.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getImagenSelfie() {
        return imagenSelfie;
    }

    /**
     * Define el valor de la propiedad imagenSelfie.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setImagenSelfie(byte[] value) {
        this.imagenSelfie = value;
    }

    /**
     * Obtiene el valor de la propiedad imagenFrenteFirma.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getImagenFrenteFirma() {
        return imagenFrenteFirma;
    }

    /**
     * Define el valor de la propiedad imagenFrenteFirma.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setImagenFrenteFirma(byte[] value) {
        this.imagenFrenteFirma = value;
    }

    /**
     * Obtiene el valor de la propiedad imagenCompleta.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getImagenCompleta() {
        return imagenCompleta;
    }

    /**
     * Define el valor de la propiedad imagenCompleta.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setImagenCompleta(byte[] value) {
        this.imagenCompleta = value;
    }

}
