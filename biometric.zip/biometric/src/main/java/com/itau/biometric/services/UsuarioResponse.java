
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para UsuarioResponse complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="UsuarioResponse">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.bytte.com.co/}Response">
 *       &lt;sequence>
 *         &lt;element name="Usuario" type="{http://casb.bytte.com.co/}UsuarioEnrolamiento" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UsuarioResponse", propOrder = {
    "usuario"
})
public class UsuarioResponse
    extends Response
{

    @XmlElement(name = "Usuario")
    protected UsuarioEnrolamiento usuario;

    /**
     * Obtiene el valor de la propiedad usuario.
     * 
     * @return
     *     possible object is
     *     {@link UsuarioEnrolamiento }
     *     
     */
    public UsuarioEnrolamiento getUsuario() {
        return usuario;
    }

    /**
     * Define el valor de la propiedad usuario.
     * 
     * @param value
     *     allowed object is
     *     {@link UsuarioEnrolamiento }
     *     
     */
    public void setUsuario(UsuarioEnrolamiento value) {
        this.usuario = value;
    }

}
