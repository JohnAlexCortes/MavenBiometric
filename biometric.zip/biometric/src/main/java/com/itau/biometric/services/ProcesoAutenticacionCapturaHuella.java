
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ProcesoAutenticacionCapturaHuella complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ProcesoAutenticacionCapturaHuella">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Imagen" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="WSQImagen" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="Template" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TemplateVersion" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="IdFingerprint" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="URL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProcesoAutenticacionCapturaHuella", propOrder = {
    "imagen",
    "wsqImagen",
    "template",
    "templateVersion",
    "idFingerprint",
    "url"
})
public class ProcesoAutenticacionCapturaHuella {

    @XmlElement(name = "Imagen")
    protected byte[] imagen;
    @XmlElement(name = "WSQImagen")
    protected byte[] wsqImagen;
    @XmlElement(name = "Template")
    protected String template;
    @XmlElement(name = "TemplateVersion")
    protected int templateVersion;
    @XmlElement(name = "IdFingerprint")
    protected int idFingerprint;
    @XmlElement(name = "URL")
    protected String url;

    /**
     * Obtiene el valor de la propiedad imagen.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getImagen() {
        return imagen;
    }

    /**
     * Define el valor de la propiedad imagen.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setImagen(byte[] value) {
        this.imagen = value;
    }

    /**
     * Obtiene el valor de la propiedad wsqImagen.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getWSQImagen() {
        return wsqImagen;
    }

    /**
     * Define el valor de la propiedad wsqImagen.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setWSQImagen(byte[] value) {
        this.wsqImagen = value;
    }

    /**
     * Obtiene el valor de la propiedad template.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemplate() {
        return template;
    }

    /**
     * Define el valor de la propiedad template.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemplate(String value) {
        this.template = value;
    }

    /**
     * Obtiene el valor de la propiedad templateVersion.
     * 
     */
    public int getTemplateVersion() {
        return templateVersion;
    }

    /**
     * Define el valor de la propiedad templateVersion.
     * 
     */
    public void setTemplateVersion(int value) {
        this.templateVersion = value;
    }

    /**
     * Obtiene el valor de la propiedad idFingerprint.
     * 
     */
    public int getIdFingerprint() {
        return idFingerprint;
    }

    /**
     * Define el valor de la propiedad idFingerprint.
     * 
     */
    public void setIdFingerprint(int value) {
        this.idFingerprint = value;
    }

    /**
     * Obtiene el valor de la propiedad url.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getURL() {
        return url;
    }

    /**
     * Define el valor de la propiedad url.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setURL(String value) {
        this.url = value;
    }

}
