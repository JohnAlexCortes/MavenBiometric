
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ConvertClienteResponse complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ConvertClienteResponse">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.bytte.com.co/}Response">
 *       &lt;sequence>
 *         &lt;element name="ClienteProceso" type="{http://casb.bytte.com.co/}DocumentoData" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConvertClienteResponse", propOrder = {
    "clienteProceso"
})
public class ConvertClienteResponse
    extends Response
{

    @XmlElement(name = "ClienteProceso")
    protected DocumentoData clienteProceso;

    /**
     * Obtiene el valor de la propiedad clienteProceso.
     * 
     * @return
     *     possible object is
     *     {@link DocumentoData }
     *     
     */
    public DocumentoData getClienteProceso() {
        return clienteProceso;
    }

    /**
     * Define el valor de la propiedad clienteProceso.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentoData }
     *     
     */
    public void setClienteProceso(DocumentoData value) {
        this.clienteProceso = value;
    }

}
