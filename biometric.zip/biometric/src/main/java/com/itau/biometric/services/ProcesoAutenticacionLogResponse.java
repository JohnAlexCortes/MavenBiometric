
package com.itau.biometric.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para ProcesoAutenticacionLogResponse complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ProcesoAutenticacionLogResponse">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.bytte.com.co/}Response">
 *       &lt;sequence>
 *         &lt;element name="IdLog" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IdProceso" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FechaProceso" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="Ultimo" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="BarCodeBase64" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StatusFingerprint" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="StatusAniOCR" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="StatusANIBarCode" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="StatusOCRBarCode" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="StatusFace" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="StatusDocumento" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="ScoreFingerprintValor" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ScoreFingerprint" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ScoreAniOCR" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ScoreANIBarcode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ScoreOCRBarCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ScoreFace" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ScoreFaceValor" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ScoreDocumento" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Finalizado" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="AutenticadoDocumento" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="NumeroDocumento" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ImagenDocumento" type="{http://casb.bytte.com.co/}ProcesoAutenticacionDocumento" minOccurs="0"/>
 *         &lt;element name="HuellasProceso" type="{http://casb.bytte.com.co/}ArrayOfProcesoAutenticacionCapturaHuella" minOccurs="0"/>
 *         &lt;element name="BarCodeData" type="{http://casb.bytte.com.co/}DocumentoData" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProcesoAutenticacionLogResponse", propOrder = {
    "idLog",
    "version",
    "idProceso",
    "fechaProceso",
    "ultimo",
    "barCodeBase64",
    "statusFingerprint",
    "statusAniOCR",
    "statusANIBarCode",
    "statusOCRBarCode",
    "statusFace",
    "statusDocumento",
    "scoreFingerprintValor",
    "scoreFingerprint",
    "scoreAniOCR",
    "scoreANIBarcode",
    "scoreOCRBarCode",
    "scoreFace",
    "scoreFaceValor",
    "scoreDocumento",
    "finalizado",
    "autenticadoDocumento",
    "numeroDocumento",
    "imagenDocumento",
    "huellasProceso",
    "barCodeData"
})
public class ProcesoAutenticacionLogResponse
    extends Response
{

    @XmlElement(name = "IdLog")
    protected String idLog;
    @XmlElement(name = "Version")
    protected String version;
    @XmlElement(name = "IdProceso")
    protected String idProceso;
    @XmlElement(name = "FechaProceso", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar fechaProceso;
    @XmlElement(name = "Ultimo")
    protected boolean ultimo;
    @XmlElement(name = "BarCodeBase64")
    protected String barCodeBase64;
    @XmlElement(name = "StatusFingerprint")
    protected short statusFingerprint;
    @XmlElement(name = "StatusAniOCR")
    protected short statusAniOCR;
    @XmlElement(name = "StatusANIBarCode")
    protected short statusANIBarCode;
    @XmlElement(name = "StatusOCRBarCode", required = true, type = Short.class, nillable = true)
    protected Short statusOCRBarCode;
    @XmlElement(name = "StatusFace")
    protected short statusFace;
    @XmlElement(name = "StatusDocumento", required = true, type = Short.class, nillable = true)
    protected Short statusDocumento;
    @XmlElement(name = "ScoreFingerprintValor", required = true, type = Integer.class, nillable = true)
    protected Integer scoreFingerprintValor;
    @XmlElement(name = "ScoreFingerprint", required = true, type = Integer.class, nillable = true)
    protected Integer scoreFingerprint;
    @XmlElement(name = "ScoreAniOCR", required = true, type = Integer.class, nillable = true)
    protected Integer scoreAniOCR;
    @XmlElement(name = "ScoreANIBarcode", required = true, type = Integer.class, nillable = true)
    protected Integer scoreANIBarcode;
    @XmlElement(name = "ScoreOCRBarCode", required = true, type = Integer.class, nillable = true)
    protected Integer scoreOCRBarCode;
    @XmlElement(name = "ScoreFace", required = true, type = Integer.class, nillable = true)
    protected Integer scoreFace;
    @XmlElement(name = "ScoreFaceValor", required = true, type = Integer.class, nillable = true)
    protected Integer scoreFaceValor;
    @XmlElement(name = "ScoreDocumento", required = true, type = Integer.class, nillable = true)
    protected Integer scoreDocumento;
    @XmlElement(name = "Finalizado", required = true, type = Boolean.class, nillable = true)
    protected Boolean finalizado;
    @XmlElement(name = "AutenticadoDocumento")
    protected boolean autenticadoDocumento;
    @XmlElement(name = "NumeroDocumento")
    protected String numeroDocumento;
    @XmlElement(name = "ImagenDocumento")
    protected ProcesoAutenticacionDocumento imagenDocumento;
    @XmlElement(name = "HuellasProceso")
    protected ArrayOfProcesoAutenticacionCapturaHuella huellasProceso;
    @XmlElement(name = "BarCodeData")
    protected DocumentoData barCodeData;

    /**
     * Obtiene el valor de la propiedad idLog.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdLog() {
        return idLog;
    }

    /**
     * Define el valor de la propiedad idLog.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdLog(String value) {
        this.idLog = value;
    }

    /**
     * Obtiene el valor de la propiedad version.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersion() {
        return version;
    }

    /**
     * Define el valor de la propiedad version.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersion(String value) {
        this.version = value;
    }

    /**
     * Obtiene el valor de la propiedad idProceso.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdProceso() {
        return idProceso;
    }

    /**
     * Define el valor de la propiedad idProceso.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdProceso(String value) {
        this.idProceso = value;
    }

    /**
     * Obtiene el valor de la propiedad fechaProceso.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFechaProceso() {
        return fechaProceso;
    }

    /**
     * Define el valor de la propiedad fechaProceso.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechaProceso(XMLGregorianCalendar value) {
        this.fechaProceso = value;
    }

    /**
     * Obtiene el valor de la propiedad ultimo.
     * 
     */
    public boolean isUltimo() {
        return ultimo;
    }

    /**
     * Define el valor de la propiedad ultimo.
     * 
     */
    public void setUltimo(boolean value) {
        this.ultimo = value;
    }

    /**
     * Obtiene el valor de la propiedad barCodeBase64.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBarCodeBase64() {
        return barCodeBase64;
    }

    /**
     * Define el valor de la propiedad barCodeBase64.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBarCodeBase64(String value) {
        this.barCodeBase64 = value;
    }

    /**
     * Obtiene el valor de la propiedad statusFingerprint.
     * 
     */
    public short getStatusFingerprint() {
        return statusFingerprint;
    }

    /**
     * Define el valor de la propiedad statusFingerprint.
     * 
     */
    public void setStatusFingerprint(short value) {
        this.statusFingerprint = value;
    }

    /**
     * Obtiene el valor de la propiedad statusAniOCR.
     * 
     */
    public short getStatusAniOCR() {
        return statusAniOCR;
    }

    /**
     * Define el valor de la propiedad statusAniOCR.
     * 
     */
    public void setStatusAniOCR(short value) {
        this.statusAniOCR = value;
    }

    /**
     * Obtiene el valor de la propiedad statusANIBarCode.
     * 
     */
    public short getStatusANIBarCode() {
        return statusANIBarCode;
    }

    /**
     * Define el valor de la propiedad statusANIBarCode.
     * 
     */
    public void setStatusANIBarCode(short value) {
        this.statusANIBarCode = value;
    }

    /**
     * Obtiene el valor de la propiedad statusOCRBarCode.
     * 
     * @return
     *     possible object is
     *     {@link Short }
     *     
     */
    public Short getStatusOCRBarCode() {
        return statusOCRBarCode;
    }

    /**
     * Define el valor de la propiedad statusOCRBarCode.
     * 
     * @param value
     *     allowed object is
     *     {@link Short }
     *     
     */
    public void setStatusOCRBarCode(Short value) {
        this.statusOCRBarCode = value;
    }

    /**
     * Obtiene el valor de la propiedad statusFace.
     * 
     */
    public short getStatusFace() {
        return statusFace;
    }

    /**
     * Define el valor de la propiedad statusFace.
     * 
     */
    public void setStatusFace(short value) {
        this.statusFace = value;
    }

    /**
     * Obtiene el valor de la propiedad statusDocumento.
     * 
     * @return
     *     possible object is
     *     {@link Short }
     *     
     */
    public Short getStatusDocumento() {
        return statusDocumento;
    }

    /**
     * Define el valor de la propiedad statusDocumento.
     * 
     * @param value
     *     allowed object is
     *     {@link Short }
     *     
     */
    public void setStatusDocumento(Short value) {
        this.statusDocumento = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreFingerprintValor.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getScoreFingerprintValor() {
        return scoreFingerprintValor;
    }

    /**
     * Define el valor de la propiedad scoreFingerprintValor.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setScoreFingerprintValor(Integer value) {
        this.scoreFingerprintValor = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreFingerprint.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getScoreFingerprint() {
        return scoreFingerprint;
    }

    /**
     * Define el valor de la propiedad scoreFingerprint.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setScoreFingerprint(Integer value) {
        this.scoreFingerprint = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreAniOCR.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getScoreAniOCR() {
        return scoreAniOCR;
    }

    /**
     * Define el valor de la propiedad scoreAniOCR.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setScoreAniOCR(Integer value) {
        this.scoreAniOCR = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreANIBarcode.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getScoreANIBarcode() {
        return scoreANIBarcode;
    }

    /**
     * Define el valor de la propiedad scoreANIBarcode.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setScoreANIBarcode(Integer value) {
        this.scoreANIBarcode = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreOCRBarCode.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getScoreOCRBarCode() {
        return scoreOCRBarCode;
    }

    /**
     * Define el valor de la propiedad scoreOCRBarCode.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setScoreOCRBarCode(Integer value) {
        this.scoreOCRBarCode = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreFace.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getScoreFace() {
        return scoreFace;
    }

    /**
     * Define el valor de la propiedad scoreFace.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setScoreFace(Integer value) {
        this.scoreFace = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreFaceValor.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getScoreFaceValor() {
        return scoreFaceValor;
    }

    /**
     * Define el valor de la propiedad scoreFaceValor.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setScoreFaceValor(Integer value) {
        this.scoreFaceValor = value;
    }

    /**
     * Obtiene el valor de la propiedad scoreDocumento.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getScoreDocumento() {
        return scoreDocumento;
    }

    /**
     * Define el valor de la propiedad scoreDocumento.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setScoreDocumento(Integer value) {
        this.scoreDocumento = value;
    }

    /**
     * Obtiene el valor de la propiedad finalizado.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isFinalizado() {
        return finalizado;
    }

    /**
     * Define el valor de la propiedad finalizado.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setFinalizado(Boolean value) {
        this.finalizado = value;
    }

    /**
     * Obtiene el valor de la propiedad autenticadoDocumento.
     * 
     */
    public boolean isAutenticadoDocumento() {
        return autenticadoDocumento;
    }

    /**
     * Define el valor de la propiedad autenticadoDocumento.
     * 
     */
    public void setAutenticadoDocumento(boolean value) {
        this.autenticadoDocumento = value;
    }

    /**
     * Obtiene el valor de la propiedad numeroDocumento.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    /**
     * Define el valor de la propiedad numeroDocumento.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroDocumento(String value) {
        this.numeroDocumento = value;
    }

    /**
     * Obtiene el valor de la propiedad imagenDocumento.
     * 
     * @return
     *     possible object is
     *     {@link ProcesoAutenticacionDocumento }
     *     
     */
    public ProcesoAutenticacionDocumento getImagenDocumento() {
        return imagenDocumento;
    }

    /**
     * Define el valor de la propiedad imagenDocumento.
     * 
     * @param value
     *     allowed object is
     *     {@link ProcesoAutenticacionDocumento }
     *     
     */
    public void setImagenDocumento(ProcesoAutenticacionDocumento value) {
        this.imagenDocumento = value;
    }

    /**
     * Obtiene el valor de la propiedad huellasProceso.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfProcesoAutenticacionCapturaHuella }
     *     
     */
    public ArrayOfProcesoAutenticacionCapturaHuella getHuellasProceso() {
        return huellasProceso;
    }

    /**
     * Define el valor de la propiedad huellasProceso.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfProcesoAutenticacionCapturaHuella }
     *     
     */
    public void setHuellasProceso(ArrayOfProcesoAutenticacionCapturaHuella value) {
        this.huellasProceso = value;
    }

    /**
     * Obtiene el valor de la propiedad barCodeData.
     * 
     * @return
     *     possible object is
     *     {@link DocumentoData }
     *     
     */
    public DocumentoData getBarCodeData() {
        return barCodeData;
    }

    /**
     * Define el valor de la propiedad barCodeData.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentoData }
     *     
     */
    public void setBarCodeData(DocumentoData value) {
        this.barCodeData = value;
    }

}
