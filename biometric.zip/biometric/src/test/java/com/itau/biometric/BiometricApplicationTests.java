package com.itau.biometric;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.itau.biometric.controllers.LlammarWsdl;
import com.itau.biometric.services.Calculator;
import com.itau.biometric.services.CalculatorSoap;
import com.itau.biometric.services.IServicioAutenticacion;
import com.itau.biometric.services.ServicioAutenticacion;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BiometricApplicationTests {

	private static final Logger log= LoggerFactory.getLogger(LlammarWsdl.class);
	
	@Test
	public void contextLoads() {
		
		log.info("---Inicio uuuuu-------->>>");
		 CalculatorSoap servicio2 = new  Calculator().getCalculatorSoap();
		 IServicioAutenticacion servicio = new ServicioAutenticacion().getCASBProcesoAutenticacionService();
		 log.info("---Inicio ppppp-------->>>");
		 
		 try 
		 {
			 servicio2.add(1, 2);
			 servicio.consultaUsuario("78787878");
			 log.info("---Inicio-------->>>");
		 } catch (Exception e) {
			 log.info("---Error-------->>>" + e.getMessage());
		 }
		
	}

}
